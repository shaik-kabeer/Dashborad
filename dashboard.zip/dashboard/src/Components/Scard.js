import React from 'react'
import Card from './Card';
const Scard = () => {
    return (<>

        <div className='container my-3 mx-3'>
            <div className='container my-3 mx-3'>
                <h2>THE EMPLOYEE'S ID</h2>

                <div className='row'>
                    {
                        results.map((element) => {
                            return <div className='col-md-4' key={element.id}>
                                <Card Id={element.id} employee_name={element.employee_name}
                                    employee_salary={element.employee_salary} employee_age={element.employee_age} />
                            </div>

                        })} </div>







                {/* <div className="card" style={{ width: "18rem"} }>

                            <div className="card-body">
                           
                                <h5 className="card-title"> ID{Id}</h5>
                                <p className="card-text"> Employee Name :{employee_name}</p>
                                <p className="card-text"> Employee salary:{employee_salary}...</p>
                                <p className="card-text">Employee Age :{employee_age}</p>
                            {/* //    //<p className="card-text"> {profile_image}</p> */}
                       {/* <a href={Id} target='_blank' className="btn  btn-primary">Read More</a>  */}
                        {/* </div>*/}
                        </div> 
             </div>



        
    </>)
}

export default Scard
