import React, { useState } from 'react'
import Card from './Card';
//import {Fasearch} from"react-icons/fa"
export const Last = ({setResults}) => {
    const [input,setInput]= useState("");
    
   const fetchData=async(value)=>{


        fetch("https://dummy.restapiexample.com/api/v1/employees").then((response)=>response.json()).then(json=>{
            const results=json.filter((element)=>{
                return  <div className='col-md-4' key={element.id}>
                <Card Id={element.id} employee_name={element.employee_name}
                    employee_salary={element.employee_salary} employee_age={element.employee_age} />
            </div>


                //value && element.employee_id&&element.employee_name.toLowerCase().includes(value)
            });
            // console.log(results)

             setResults(results);

             });

             const handleChange=(value)=>{
                setInput(value);
                this.fetchData(value);
                };
        
        
        
    
  return (
    <div className='input-wrapper'>
        <search id="search-icon"/>
        <input placeholder='type to search...'value={input} onChange={(e)=>handleChange(e.target.value)}/>
      
    </div>
  );
};}

 export default Last
