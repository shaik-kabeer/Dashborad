
import './App.css';
import React, { Component } from 'react'
import Nav from './Components/Nav';
import Last from './Components/Last';


export default class App extends Component {
 
  render() {
    return (
      <>
        <div>
          <div className='container my-3 mx-90' >
            <h1 >THE EMPLOY DASHBOARD</h1>
            </div>
            <div className='container my-3 mx-90'>
            {/* <Searching /> */}
            
           {/* <Final/> */}
             
             {/* <Last/>  */}
          </div>
        </div>
        <Nav /> 
      </>)
  }
}


// export default App;
