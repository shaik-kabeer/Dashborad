import React, { Component } from 'react'
export class Card extends Component {
    render() {
        let { Id, employee_name, employee_salary,employee_age} = this.props
        return (
        <>
                
                    <div className='container my-3 mx-3'>
                        <div className="card" style={{ width: "18rem"} }>

                        {/* <div>
                        <form className="d-flex" role="search">
                            <input className="form-control me-2" type="search" placeholder="Search"  />
                            <button id="btn" className="btn btn-outline-success" type="submit">Search  </button>
                             {/* onSubmit{(event) => {
                                setSearchTerm(event.target.value);
                            }} */}
                           
    
                           {/* // <img src={profile_image} className="card-img-top" alt="..." /> */}
                            <div className="card-body">
                           
                                <h5 className="card-title"> ID{Id}</h5>
                                <p className="card-text"> Employee Name :{employee_name}</p>
                                <p className="card-text"> Employee salary:{employee_salary}...</p>
                                <p className="card-text">Employee Age :{employee_age}</p>
                            {/* //    //<p className="card-text"> {profile_image}</p> */}
                                 <a href={[Id,employee_name,employee_salary,employee_age]} target="_blank" className="btn  btn-primary">Read More</a> 
                            </div>
                        </div>
                    </div>
                   
                </>  )
       }
    }

                export default Card
