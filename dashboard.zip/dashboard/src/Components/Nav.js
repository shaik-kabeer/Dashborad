import React, { Component} from 'react'
import Card from './Card';
//import Scard from './Scard'
//import Last from './Last'

export class Nav extends Component {

    //const [input, setInput] =>useState()
    data = [{}]
    constructor() {
        super();
        console.log("hello i am a contructor from nav component");
        this.state = {
            data: this.data
        }
    }
    async componentDidMount() {
        let url = "https://dummy.restapiexample.com/api/v1/employees";
        let data = await fetch(url);
        let parsedData = await data.json()
        console.log(parsedData);
       this.setState({ data: parsedData.data })

    //    const handleupclick = () => {

    //     console.log("uppercase was clicked" + text);
    //     let  = text.toUpperCase();
    //     setText(newtext)
    // }

    //   (data).then((response)=>response.json()).then(json=>{
    //       const results=json.filter((element)=>{
    //       return
    //           <div className='col-md-4' key={element.id}>
    //       <Card Id={element.id} employee_name={element.employee_name}
    //               employee_salary={element.employee_salary} employee_age={element.employee_age} />
    //       </div> });
    //      // console.log(results)

    //       this.setResults(results);

    //       });
    // const handleonchange = (event) => {
    //     setText(event.target.value)


    // }




// }

    }


     render() {

        
      
//         const handleonclick = (value) => {

//             const fetchData = (value) => {
//                 // fetch('https://dummy.restapiexample.com/api/v1/employees')
//                 fetch(this.data)
//                 // .then((response) => response.json())
//                     .then((json) => {
// const results = json.filter((element)=>{
// return element &&element.Id&&element.employee_name.toLowerCase()

//                     });


//                         console.log(json)
//                     });
//                 const handleonclick = (value) => {

//                     setInput(value);
//                     fetchData(value);
//                 }
//             }}
//  const handleonclick=(e)=>{
//     {
//         this.state.data.filter((element) => {
//             return <div className='col-md-4' key={element.id}>
//                 <Card Id={element.id} employee_name={element.employee_name}
//                     employee_salary={element.employee_salary} employee_age={element.employee_age} />
//             </div>

//         })} 
            // const handleonclick = (event) => {
            //     setname(event.target.value);
            //   }
   //{/* <div class="form-floating">
//   <input type="password" class="form-control" id="floatingPassword" placeholder="Password">
//   <label for="floatingPassword">Password</label>/
//   <button type="submit" class="btn btn-primary">Submit</button>
// //</input></div> */}
//

            return (
                <>


                    <div>


{/* 
<div class="form-floating">
  <input type="password" class="form-control" id="floatingPassword" placeholder="Password"/>
  <label for="floatingPassword">Password</label>/
  <button type="submit" class="btn btn-primary">Submit</button>
</div>  */}

{/* // <div class="input-group">
//   <div class="form-outline">
//     <input type="search" id="form1" class="form-control" />
//     <label class="form-label" for="form1"value={text} >Search</label>
//   </div>
//   <button className="btn btn-primary mx-4" onClick={this.handleupclick}>Convert to Uppercase</button>
//     <i class="fas fa-search"></i>

  
// </div> */}


                {/* handleonclick=(value)={
                 <div className='row'>
                               {
                                    this.state.results.filter((element) => {
                                        return <div className='col-md-4' key={element.id}>
                                            <Card Id={element.id} employee_name={element.employee_name}
                                                employee_salary={element.employee_salary} employee_age={element.employee_age} />
                                        </div>

                                    })}
                                     </div> */}

                                
                      {/* <Last setResults={setResults}/>
                     <Scard results={results}/>
                          */}



                        <div className='container my-3 mx-3'>
                            <h2>THE EMPLOYEE'S ID</h2>

                            <div className='row'>
                                {
                                    this.state.data.map((element) => {
                                        return <div className='col-md-4' key={element.id}>
                                            <Card Id={element.id} employee_name={element.employee_name}
                                                employee_salary={element.employee_salary} employee_age={element.employee_age} />
                                        </div>

                                    })} </div>

                        </div>

                    </div>
                </>
            )
        }
    }

export default Nav
